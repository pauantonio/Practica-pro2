var searchData=
[
  ['inicialitza_5fcluster',['inicialitza_cluster',['../class_cjt__clusters.html#a0c0922c708fb014720a53bd560ebed61',1,'Cjt_clusters']]]
];
