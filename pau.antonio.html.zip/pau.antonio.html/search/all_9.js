var searchData=
[
  ['taula_5fdistancies',['taula_distancies',['../class_cjt__especies.html#ad66ac0438cce1ecf2c5553cb98f1085a',1,'Cjt_especies']]],
  ['taula_5fdistancies_5fclusters',['taula_distancies_clusters',['../class_cjt__clusters.html#ab243c775e0e2d64905ce744490d2f898',1,'Cjt_clusters']]]
];
