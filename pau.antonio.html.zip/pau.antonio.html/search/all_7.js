var searchData=
[
  ['pràctica_20pro2_3a_20construcció_20d_27un_20arbre_20filogenètic_2e',['Pràctica PRO2: Construcció d&apos;un arbre filogenètic.',['../index.html',1,'']]]
];
