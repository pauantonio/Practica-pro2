var searchData=
[
  ['left',['left',['../class_bin_tree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree']]],
  ['llegir',['llegir',['../class_cjt__especies.html#a4d0f724a9540f96244f86913f916650c',1,'Cjt_especies::llegir()'],['../class_cluster.html#addf8d8d2beb59cf5b5fd7e0eed491e7e',1,'Cluster::llegir()'],['../class_especie.html#a7384add391d2684c4fb6bdf8a535fba3',1,'Especie::llegir()']]]
];
