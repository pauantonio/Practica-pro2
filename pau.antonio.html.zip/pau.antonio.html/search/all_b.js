var searchData=
[
  ['wpgma_5fpas',['wpgma_pas',['../class_cjt__clusters.html#ae5d7fd65b9070ea2e7240d78fefd0f6e',1,'Cjt_clusters']]],
  ['wpgma_5ftotal',['wpgma_total',['../class_cjt__clusters.html#a755fca978c7d4b499e2c7b0963136354',1,'Cjt_clusters']]]
];
