var searchData=
[
  ['cjt_5fclusters',['Cjt_clusters',['../class_cjt__clusters.html#a10dd63eab0e8ea5b1ed13e81412d47a9',1,'Cjt_clusters']]],
  ['cjt_5fespecies',['Cjt_especies',['../class_cjt__especies.html#ae1bc936c1803488324b1ba47a61ab68c',1,'Cjt_especies']]],
  ['cluster',['Cluster',['../class_cluster.html#a4702942c6848ae6fbb7de215b49797d5',1,'Cluster::Cluster(const string &amp;id)'],['../class_cluster.html#a6b3458644e7db37186d77b4a288cb527',1,'Cluster::Cluster(const Cluster &amp;c1, const Cluster &amp;c2, const double &amp;dist)']]],
  ['consultar_5fcluster',['consultar_cluster',['../class_cluster.html#a6e681a525f139e7203ab8b33808ce9b0',1,'Cluster']]],
  ['consultar_5fdistancia',['consultar_distancia',['../class_cjt__especies.html#a7646c0a8ad4598e1e95835c2cecfadf1',1,'Cjt_especies::consultar_distancia()'],['../class_especie.html#a1b42d30bf773b236ba8300b8cf6aeb5e',1,'Especie::consultar_distancia()']]],
  ['consultar_5fespecie',['consultar_especie',['../class_cjt__especies.html#a3e6bc7a95c27e6d9fdf97d2b4e43e8ef',1,'Cjt_especies']]],
  ['consultar_5fgen',['consultar_gen',['../class_especie.html#a850af2b59a21e2d801c59d76ba5c1a98',1,'Especie']]],
  ['consultar_5fidentificador',['consultar_identificador',['../class_cjt__especies.html#a568f568d71c66912b69a0c33cd97717d',1,'Cjt_especies']]],
  ['consultar_5fminim',['consultar_minim',['../class_taula__distancies.html#aa5019b0f96132f4a5c74117476688a1f',1,'Taula_distancies']]],
  ['consultar_5ftamany',['consultar_tamany',['../class_cjt__clusters.html#a4b04153b8785ddf41e4fbffa14a68298',1,'Cjt_clusters']]],
  ['consultar_5ftaula',['consultar_taula',['../class_cjt__especies.html#a696b5f4f7df52e869c3c5611f50e1aed',1,'Cjt_especies']]],
  ['crea_5fespecie',['crea_especie',['../class_cjt__especies.html#a6413c062ece1d559a050bac7a6d02fc9',1,'Cjt_especies']]]
];
