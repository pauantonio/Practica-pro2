var searchData=
[
  ['taula_5fdistancies_2ecc',['Taula_distancies.cc',['../_taula__distancies_8cc.html',1,'']]],
  ['taula_5fdistancies_2ehh',['Taula_distancies.hh',['../_taula__distancies_8hh.html',1,'']]]
];
