var searchData=
[
  ['taula_5fdistancies',['Taula_distancies',['../class_taula__distancies.html#a10e2cc414497ee7863d7da82089d21dd',1,'Taula_distancies']]]
];
