var searchData=
[
  ['buidar',['buidar',['../class_taula__distancies.html#ae22c14a52093c604b7462cf1c7f621aa',1,'Taula_distancies']]]
];
