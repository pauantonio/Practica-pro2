var searchData=
[
  ['llegir',['llegir',['../class_cjt__especies.html#a4d0f724a9540f96244f86913f916650c',1,'Cjt_especies']]]
];
