var searchData=
[
  ['taula_5fdistancies',['Taula_distancies',['../class_taula__distancies.html',1,'']]]
];
