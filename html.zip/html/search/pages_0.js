var searchData=
[
  ['construcció_20d_27un_20arbre_20filogenètic',['Construcció d&apos;un arbre filogenètic',['../index.html',1,'']]]
];
