var searchData=
[
  ['actualitza_5ftaula',['actualitza_taula',['../class_taula__distancies.html#a74f2a7b5e427f65e0e7727e2867f5bce',1,'Taula_distancies']]],
  ['afegeix_5fcolumna',['afegeix_columna',['../class_taula__distancies.html#a060f40fade23f8e1e4c8c246d0a44f20',1,'Taula_distancies']]],
  ['afegeix_5ffila',['afegeix_fila',['../class_taula__distancies.html#a3477fe6df2fca824be64cd6d9deac88e',1,'Taula_distancies']]]
];
