var searchData=
[
  ['incrementa_5fiterador',['incrementa_iterador',['../class_cjt__especies.html#aad700371bcd8ee8109b9165b5ddf9f57',1,'Cjt_especies']]],
  ['inicialitza_5fcluster',['inicialitza_cluster',['../class_cjt__clusters.html#a7549f8a4f45789fb34cdefc7df553102',1,'Cjt_clusters']]],
  ['inicialitza_5fiterador',['inicialitza_iterador',['../class_cjt__especies.html#afa7ad734aaad2a7cff1a0a432838fb3e',1,'Cjt_especies']]]
];
