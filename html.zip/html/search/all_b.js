var searchData=
[
  ['taula',['taula',['../class_cjt__clusters.html#a06c65c890c72c542f572f7e286b82932',1,'Cjt_clusters::taula()'],['../class_cjt__especies.html#a4b3e5e324e735382b2c40bab7a2650c6',1,'Cjt_especies::taula()'],['../class_taula__distancies.html#a66e38d2ce44e23910e11efd5df9572f4',1,'Taula_distancies::taula()']]],
  ['taula_5fdistancies',['Taula_distancies',['../class_taula__distancies.html',1,'Taula_distancies'],['../class_taula__distancies.html#a10e2cc414497ee7863d7da82089d21dd',1,'Taula_distancies::Taula_distancies()']]],
  ['taula_5fdistancies_2ecc',['Taula_distancies.cc',['../_taula__distancies_8cc.html',1,'']]],
  ['taula_5fdistancies_2ehh',['Taula_distancies.hh',['../_taula__distancies_8hh.html',1,'']]]
];
