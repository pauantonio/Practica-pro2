var indexSectionsWithContent =
{
  0: "abcefgiklmpt~",
  1: "cet",
  2: "cept",
  3: "abcefilmpt~",
  4: "cgikt",
  5: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Variables",
  5: "Pàgines"
};

